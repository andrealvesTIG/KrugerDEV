/**
 * Financials + Multi-Year WBS routes.
 *
 * Self-contained Express route module. Mount it from your main routes
 * registration file like this:
 *
 *   import { registerFinancialsRoutes } from "./financialsRoutes";
 *   registerFinancialsRoutes(app, {
 *     db,
 *     storage: financialsStorage,
 *     requireAuth,                      // YOUR auth middleware — REQUIRED
 *     getUserId: (req) => req.user?.id, // extract the auth user id
 *     canAccessOrg,                     // optional org-membership guard
 *   });
 *
 * Dependencies your project must provide (see RegisterDeps below for full types):
 *   - `db`          : the drizzle Postgres client (for the WBS endpoints).
 *   - `storage`     : a FinancialsStorage facade implemented against your data layer.
 *   - `requireAuth` : Express middleware enforcing authentication. Without it
 *                     these endpoints are open to the public.
 *   - `getUserId`   : (req) => string | null    extract the auth user id from req.
 *   - `canAccessOrg`: (optional) per-organization access guard.
 *   - The schema slice from `shared/financialsSchema.ts` must be present in
 *     your shared schema folder.
 *
 * The cost-items endpoints go through a small `storage` facade that you
 * implement against your own data layer. The WBS endpoints query the
 * `multiYearWbs` table directly via drizzle.
 */

import type { Express, Request, RequestHandler } from "express";
import { eq } from "drizzle-orm";
import type { NodePgDatabase } from "drizzle-orm/node-postgres";
import {
  multiYearWbs,
  type CostItem,
  type InsertCostItem,
  type InsertCostItemChangeLog,
} from "../shared/financialsSchema";

// Narrow Drizzle-shaped contract — covers both node-postgres and neon-serverless
// drivers. If your project's db client doesn't match, you can pass it as
// `db as unknown as FinancialsDb` at the registration site.
export type FinancialsDb = NodePgDatabase<Record<string, never>>;

// Field key unions used by the change-log diff so we can avoid `as any`.
const META_FIELDS = [
  "name", "wbs", "comments", "financialView", "costCategory", "costSpecification",
] as const;
const MONTH_FIELDS = [
  "aopM1","aopM2","aopM3","aopM4","aopM5","aopM6","aopM7","aopM8","aopM9","aopM10","aopM11","aopM12",
  "fcstM1","fcstM2","fcstM3","fcstM4","fcstM5","fcstM6","fcstM7","fcstM8","fcstM9","fcstM10","fcstM11","fcstM12",
  "actM1","actM2","actM3","actM4","actM5","actM6","actM7","actM8","actM9","actM10","actM11","actM12",
] as const;
type MetaField = (typeof META_FIELDS)[number];
type MonthField = (typeof MONTH_FIELDS)[number];
type TrackedField = MetaField | MonthField;

// ---------------------------------------------------------------------------
// Storage facade — implement these against your own data layer.
// ---------------------------------------------------------------------------
export interface FinancialsStorage {
  getProject(id: number): Promise<{ id: number; organizationId: number } | null>;
  getUser(id: string): Promise<{
    firstName?: string | null;
    lastName?: string | null;
    email?: string | null;
  } | null>;

  getCostItems(projectId: number, fiscalYear?: number): Promise<CostItem[]>;
  getCostItem(id: number): Promise<CostItem | null>;
  createCostItem(data: InsertCostItem): Promise<CostItem>;
  updateCostItem(id: number, patch: Partial<CostItem>): Promise<CostItem>;
  deleteCostItem(id: number): Promise<void>;

  getCostItemChangeLogs(projectId: number): Promise<Array<{
    id: number;
    costItemId: number;
    projectId: number | null;
    changeType: string;
    changeSummary: string | null;
    previousValues: string | null;
    newValues: string | null;
    changedAt: Date | null;
    changedByName: string | null;
  }>>;
  createCostItemChangeLog(data: InsertCostItemChangeLog): Promise<void>;
}

export interface RegisterDeps {
  /**
   * A drizzle pg database instance. Typed loosely as `FinancialsDb` so
   * callers using a different driver (neon-serverless, etc.) can satisfy
   * the contract via a single cast at the registration site.
   */
  db: FinancialsDb;
  storage: FinancialsStorage;
  /**
   * Extracts the authenticated user id from the request. Return null/undefined
   * for unauthenticated requests; the WBS endpoints will reject those with 401.
   */
  getUserId: (req: Request) => string | null | undefined;
  /**
   * REQUIRED authentication middleware. Mounted in front of every cost-item
   * and WBS endpoint registered by this module. Provide your own session /
   * passport guard here — without it these routes have NO auth.
   */
  requireAuth: RequestHandler;
  /**
   * Optional org-access guard. Called for cost-item AND WBS endpoints to
   * verify the user can read/write data in the project's organization.
   * Return true to allow. If omitted, only `requireAuth` is enforced.
   */
  canAccessOrg?: (userId: string, organizationId: number) => Promise<boolean>;
}

export function registerFinancialsRoutes(app: Express, deps: RegisterDeps) {
  const { db, storage, getUserId, canAccessOrg, requireAuth } = deps;

  // Helper: enforce optional org guard against the project on the route.
  async function ensureOrgAccess(
    req: Request,
    projectId: number,
  ): Promise<{ ok: true; project: { id: number; organizationId: number } } | { ok: false; status: number; message: string }> {
    const userId = getUserId(req);
    if (!userId) return { ok: false, status: 401, message: "Authentication required" };
    const project = await storage.getProject(projectId);
    if (!project) return { ok: false, status: 404, message: "Project not found" };
    if (canAccessOrg && !(await canAccessOrg(userId, project.organizationId))) {
      return { ok: false, status: 403, message: "Access denied" };
    }
    return { ok: true, project };
  }

  // ===================== COST ITEMS =====================

  // List cost items for a project (optionally filter by fiscal year)
  app.get("/api/projects/:projectId/cost-items", requireAuth, async (req, res) => {
    try {
      const projectId = Number(req.params.projectId);
      const fiscalYear = req.query.fiscalYear ? Number(req.query.fiscalYear) : undefined;
      const guard = await ensureOrgAccess(req, projectId);
      if (!guard.ok) return res.status(guard.status).json({ message: guard.message });
      const items = await storage.getCostItems(projectId, fiscalYear);
      res.json(items);
    } catch (err) {
      console.error("Error fetching cost items:", err);
      res.status(500).json({ message: "Error fetching cost items" });
    }
  });

  // Get a single cost item
  app.get("/api/cost-items/:id", requireAuth, async (req, res) => {
    const item = await storage.getCostItem(Number(req.params.id));
    if (!item) return res.status(404).json({ message: "Cost item not found" });
    const guard = await ensureOrgAccess(req, item.projectId);
    if (!guard.ok) return res.status(guard.status).json({ message: guard.message });
    res.json(item);
  });

  // Create a cost item
  app.post("/api/projects/:projectId/cost-items", requireAuth, async (req, res) => {
    try {
      const userId = getUserId(req) || null;
      const projectId = Number(req.params.projectId);
      const guard = await ensureOrgAccess(req, projectId);
      if (!guard.ok) return res.status(guard.status).json({ message: guard.message });

      const {
        name, parentId, wbs, comments, category, fiscalYear,
        financialView, costCategory, costSpecification,
        aopTotal, fcstTotal, actTotal,
        aopM1, aopM2, aopM3, aopM4, aopM5, aopM6, aopM7, aopM8, aopM9, aopM10, aopM11, aopM12,
        fcstM1, fcstM2, fcstM3, fcstM4, fcstM5, fcstM6, fcstM7, fcstM8, fcstM9, fcstM10, fcstM11, fcstM12,
        actM1, actM2, actM3, actM4, actM5, actM6, actM7, actM8, actM9, actM10, actM11, actM12,
        sortOrder,
      } = req.body;

      if (!name || !fiscalYear) {
        return res.status(400).json({ message: "name and fiscalYear are required" });
      }

      const item = await storage.createCostItem({
        projectId,
        parentId: parentId || null,
        name,
        wbs,
        comments,
        category,
        financialView,
        costCategory,
        costSpecification,
        fiscalYear,
        aopTotal, fcstTotal, actTotal,
        aopM1, aopM2, aopM3, aopM4, aopM5, aopM6, aopM7, aopM8, aopM9, aopM10, aopM11, aopM12,
        fcstM1, fcstM2, fcstM3, fcstM4, fcstM5, fcstM6, fcstM7, fcstM8, fcstM9, fcstM10, fcstM11, fcstM12,
        actM1, actM2, actM3, actM4, actM5, actM6, actM7, actM8, actM9, actM10, actM11, actM12,
        sortOrder: sortOrder || 0,
      } as InsertCostItem);

      try {
        const user = userId ? await storage.getUser(userId) : null;
        await storage.createCostItemChangeLog({
          costItemId: item.id,
          projectId,
          changedBy: userId,
          changedByName: user
            ? `${user.firstName || ""} ${user.lastName || ""}`.trim() || user.email || "Unknown"
            : "System",
          changeType: "created",
          changeSummary: `Cost item "${name}" created (${financialView || "N/A"} > ${costCategory || "N/A"} > ${costSpecification || "N/A"})`,
          previousValues: null,
          newValues: JSON.stringify({ name, financialView, costCategory, costSpecification, wbs, comments }),
        });
      } catch (logErr) {
        console.error("Error creating cost item change log:", logErr);
      }

      res.status(201).json(item);
    } catch (err) {
      console.error("Error creating cost item:", err);
      res.status(500).json({ message: "Error creating cost item" });
    }
  });

  // Update a cost item
  app.put("/api/cost-items/:id", requireAuth, async (req, res) => {
    try {
      const userId = getUserId(req) || null;
      const id = Number(req.params.id);
      const existing = await storage.getCostItem(id);
      if (!existing) return res.status(404).json({ message: "Cost item not found" });
      const guard = await ensureOrgAccess(req, existing.projectId);
      if (!guard.ok) return res.status(guard.status).json({ message: guard.message });

      const updated = await storage.updateCostItem(id, req.body);

      try {
        const user = userId ? await storage.getUser(userId) : null;
        const changedByName = user
          ? `${user.firstName || ""} ${user.lastName || ""}`.trim() || user.email || "Unknown"
          : "System";

        const changedFields: TrackedField[] = [];
        const prevValues: Partial<Record<TrackedField, CostItem[TrackedField]>> = {};
        const newValues: Partial<Record<TrackedField, unknown>> = {};
        const body = req.body as Partial<Record<TrackedField, unknown>>;

        const allFields: ReadonlyArray<TrackedField> = [...META_FIELDS, ...MONTH_FIELDS];
        for (const field of allFields) {
          const existingVal = existing[field];
          const incomingVal = body[field];
          const oldStr = String(existingVal ?? "0");
          const newStr = String(incomingVal !== undefined ? incomingVal : existingVal ?? "0");
          if (oldStr !== newStr) {
            changedFields.push(field);
            prevValues[field] = existingVal;
            newValues[field] = incomingVal;
          }
        }

        if (changedFields.length > 0) {
          const monthChanges = changedFields.filter((f): f is MonthField => (MONTH_FIELDS as readonly string[]).includes(f));
          const metaChanges = changedFields.filter((f): f is MetaField => (META_FIELDS as readonly string[]).includes(f));
          let summary = `Updated "${existing.name}"`;
          if (metaChanges.length > 0) summary += `: ${metaChanges.join(", ")} changed`;
          if (monthChanges.length > 0)
            summary += `${metaChanges.length > 0 ? "; " : ": "}${monthChanges.length} financial value(s) updated`;

          await storage.createCostItemChangeLog({
            costItemId: id,
            projectId: existing.projectId,
            changedBy: userId,
            changedByName,
            changeType: "updated",
            changeSummary: summary,
            previousValues: JSON.stringify(prevValues),
            newValues: JSON.stringify(newValues),
          });
        }
      } catch (logErr) {
        console.error("Error creating cost item change log:", logErr);
      }

      res.json(updated);
    } catch (err) {
      console.error("Error updating cost item:", err);
      res.status(500).json({ message: "Error updating cost item" });
    }
  });

  // Delete a cost item
  app.delete("/api/cost-items/:id", requireAuth, async (req, res) => {
    try {
      const userId = getUserId(req) || null;
      const id = Number(req.params.id);
      const existing = await storage.getCostItem(id);
      if (!existing) return res.status(404).json({ message: "Cost item not found" });
      const guard = await ensureOrgAccess(req, existing.projectId);
      if (!guard.ok) return res.status(guard.status).json({ message: guard.message });

      try {
        const user = userId ? await storage.getUser(userId) : null;
        await storage.createCostItemChangeLog({
          costItemId: id,
          projectId: existing.projectId,
          changedBy: userId,
          changedByName: user
            ? `${user.firstName || ""} ${user.lastName || ""}`.trim() || user.email || "Unknown"
            : "System",
          changeType: "deleted",
          changeSummary: `Cost item "${existing.name}" deleted (${existing.financialView || "N/A"} > ${existing.costCategory || "N/A"} > ${existing.costSpecification || "N/A"})`,
          previousValues: JSON.stringify({
            name: existing.name,
            financialView: existing.financialView,
            costCategory: existing.costCategory,
            costSpecification: existing.costSpecification,
          }),
          newValues: null,
        });
      } catch (logErr) {
        console.error("Error creating cost item change log:", logErr);
      }

      await storage.deleteCostItem(id);
      res.status(204).send();
    } catch (err) {
      console.error("Error deleting cost item:", err);
      res.status(500).json({ message: "Error deleting cost item" });
    }
  });

  // Cost item change history for a project
  app.get("/api/projects/:projectId/cost-items/history", requireAuth, async (req, res) => {
    try {
      const projectId = Number(req.params.projectId);
      const guard = await ensureOrgAccess(req, projectId);
      if (!guard.ok) return res.status(guard.status).json({ message: guard.message });
      const history = await storage.getCostItemChangeLogs(projectId);
      res.json(history);
    } catch (err) {
      console.error("Error fetching cost item history:", err);
      res.status(500).json({ message: "Error fetching cost item history" });
    }
  });

  // Undo last cost item change for a project
  app.post("/api/projects/:projectId/cost-items/undo", requireAuth, async (req, res) => {
    try {
      const userId = getUserId(req) || null;
      const projectId = Number(req.params.projectId);
      const guard = await ensureOrgAccess(req, projectId);
      if (!guard.ok) return res.status(guard.status).json({ message: guard.message });
      const history = await storage.getCostItemChangeLogs(projectId);
      if (history.length === 0) return res.status(400).json({ message: "No changes to undo" });

      const lastChange = history[0];

      if (lastChange.changeType === "updated" && lastChange.previousValues) {
        const prevValues = JSON.parse(lastChange.previousValues);
        const costItem = await storage.getCostItem(lastChange.costItemId!);
        if (!costItem) return res.status(404).json({ message: "Cost item no longer exists" });

        await storage.updateCostItem(lastChange.costItemId!, prevValues);

        const user = userId ? await storage.getUser(userId) : null;
        const changedByName = user
          ? `${user.firstName || ""} ${user.lastName || ""}`.trim() || user.email || "Unknown"
          : "System";
        await storage.createCostItemChangeLog({
          costItemId: lastChange.costItemId,
          projectId,
          changedBy: userId,
          changedByName,
          changeType: "updated",
          changeSummary: `Undo: reverted changes to "${costItem.name}"`,
          previousValues: lastChange.newValues,
          newValues: lastChange.previousValues,
        });
        return res.json({ message: "Change undone successfully", undoneChange: lastChange });
      } else if (lastChange.changeType === "created") {
        const costItem = await storage.getCostItem(lastChange.costItemId!);
        if (costItem) {
          await storage.deleteCostItem(lastChange.costItemId!);
          const user = userId ? await storage.getUser(userId) : null;
          const changedByName = user
            ? `${user.firstName || ""} ${user.lastName || ""}`.trim() || user.email || "Unknown"
            : "System";
          await storage.createCostItemChangeLog({
            costItemId: lastChange.costItemId,
            projectId,
            changedBy: userId,
            changedByName,
            changeType: "deleted",
            changeSummary: `Undo: removed "${costItem.name}" (reverted creation)`,
            previousValues: lastChange.newValues,
            newValues: null,
          });
        }
        return res.json({ message: "Creation undone successfully", undoneChange: lastChange });
      } else if (lastChange.changeType === "deleted") {
        return res.status(400).json({ message: "Cannot undo deletion — please recreate the item manually" });
      }

      return res.status(400).json({ message: "Cannot undo this type of change" });
    } catch (err) {
      console.error("Error undoing change:", err);
      res.status(500).json({ message: "Error undoing change" });
    }
  });

  // ===================== MULTI-YEAR WBS =====================

  app.get("/api/projects/:projectId/wbs", requireAuth, async (req, res) => {
    try {
      const projectId = Number(req.params.projectId);
      const guard = await ensureOrgAccess(req, projectId);
      if (!guard.ok) return res.status(guard.status).json({ message: guard.message });

      const entries = await db
        .select()
        .from(multiYearWbs)
        .where(eq(multiYearWbs.projectId, projectId))
        .orderBy(multiYearWbs.fiscalYear);
      res.json(entries);
    } catch (err) {
      console.error("Error fetching project WBS:", err);
      res.status(500).json({ message: "Error fetching WBS entries" });
    }
  });

  app.post("/api/projects/:projectId/wbs", requireAuth, async (req, res) => {
    try {
      const userId = getUserId(req)!;
      const projectId = Number(req.params.projectId);
      const guard = await ensureOrgAccess(req, projectId);
      if (!guard.ok) return res.status(guard.status).json({ message: guard.message });
      const project = guard.project;

      const [entry] = await db
        .insert(multiYearWbs)
        .values({
          ...req.body,
          projectId,
          organizationId: project.organizationId,
          createdBy: userId,
        })
        .returning();
      res.status(201).json(entry);
    } catch (err) {
      console.error("Error creating WBS entry:", err);
      res.status(500).json({ message: "Error creating WBS entry" });
    }
  });

  app.patch("/api/wbs/:id", requireAuth, async (req, res) => {
    try {
      const id = Number(req.params.id);
      const [existing] = await db.select().from(multiYearWbs).where(eq(multiYearWbs.id, id));
      if (!existing) return res.status(404).json({ message: "WBS entry not found" });
      const guard = await ensureOrgAccess(req, existing.projectId);
      if (!guard.ok) return res.status(guard.status).json({ message: guard.message });

      const [updated] = await db
        .update(multiYearWbs)
        .set({ ...req.body, updatedAt: new Date() })
        .where(eq(multiYearWbs.id, id))
        .returning();
      res.json(updated);
    } catch (err) {
      console.error("Error updating WBS entry:", err);
      res.status(500).json({ message: "Error updating WBS entry" });
    }
  });

  app.delete("/api/wbs/:id", requireAuth, async (req, res) => {
    try {
      const id = Number(req.params.id);
      const [existing] = await db.select().from(multiYearWbs).where(eq(multiYearWbs.id, id));
      if (!existing) return res.status(404).json({ message: "WBS entry not found" });
      const guard = await ensureOrgAccess(req, existing.projectId);
      if (!guard.ok) return res.status(guard.status).json({ message: guard.message });

      await db.delete(multiYearWbs).where(eq(multiYearWbs.id, id));
      res.json({ success: true });
    } catch (err) {
      console.error("Error deleting WBS entry:", err);
      res.status(500).json({ message: "Error deleting WBS entry" });
    }
  });
}
