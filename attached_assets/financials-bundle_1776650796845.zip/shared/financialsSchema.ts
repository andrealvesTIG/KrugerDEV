/**
 * Financials + Multi-Year WBS schema slice.
 *
 * Append the contents of this file to your existing `shared/schema.ts`,
 * or import the tables from here. Assumes you already have:
 *   - `users` table with `id` varchar primary key
 *   - `projects` table with `id` serial primary key + `organizationId`
 *   - `organizations` table with `id` serial primary key
 *
 * Required imports already in your schema (drizzle-orm/pg-core, drizzle-zod, zod):
 *   pgTable, serial, text, integer, numeric, boolean, timestamp, varchar
 *   createInsertSchema (drizzle-zod), z (zod)
 */

import {
  pgTable,
  serial,
  text,
  integer,
  numeric,
  boolean,
  timestamp,
  varchar,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// NOTE: replace these placeholder imports with references to YOUR project's
// users / projects / organizations tables.
import { users, projects, organizations } from "./schema";

// ---------------------------------------------------------------------------
// Cost Items (hierarchical financial line items with monthly breakdown)
// Hierarchy is virtual: built from `financialView > costCategory > costSpecification`.
// Fiscal year is Oct–Sep: M1=Oct, M2=Nov, ..., M12=Sep.
// ---------------------------------------------------------------------------
export const costItems = pgTable("cost_items", {
  id: serial("id").primaryKey(),
  projectId: integer("project_id").references(() => projects.id).notNull(),
  parentId: integer("parent_id"),
  name: text("name").notNull(),
  wbs: text("wbs"),
  comments: text("comments"),
  financialView: text("financial_view").notNull(), // "Capital" | "Direct Expense" | "Labor"
  costCategory: text("cost_category"),
  costSpecification: text("cost_specification"),
  category: text("category"), // legacy
  fiscalYear: integer("fiscal_year").notNull(),
  aopTotal: numeric("aop_total").default("0"),
  fcstTotal: numeric("fcst_total").default("0"),
  actTotal: numeric("act_total").default("0"),
  // AOP monthly
  aopM1: numeric("aop_m1").default("0"),
  aopM2: numeric("aop_m2").default("0"),
  aopM3: numeric("aop_m3").default("0"),
  aopM4: numeric("aop_m4").default("0"),
  aopM5: numeric("aop_m5").default("0"),
  aopM6: numeric("aop_m6").default("0"),
  aopM7: numeric("aop_m7").default("0"),
  aopM8: numeric("aop_m8").default("0"),
  aopM9: numeric("aop_m9").default("0"),
  aopM10: numeric("aop_m10").default("0"),
  aopM11: numeric("aop_m11").default("0"),
  aopM12: numeric("aop_m12").default("0"),
  // Forecast monthly
  fcstM1: numeric("fcst_m1").default("0"),
  fcstM2: numeric("fcst_m2").default("0"),
  fcstM3: numeric("fcst_m3").default("0"),
  fcstM4: numeric("fcst_m4").default("0"),
  fcstM5: numeric("fcst_m5").default("0"),
  fcstM6: numeric("fcst_m6").default("0"),
  fcstM7: numeric("fcst_m7").default("0"),
  fcstM8: numeric("fcst_m8").default("0"),
  fcstM9: numeric("fcst_m9").default("0"),
  fcstM10: numeric("fcst_m10").default("0"),
  fcstM11: numeric("fcst_m11").default("0"),
  fcstM12: numeric("fcst_m12").default("0"),
  // Actuals monthly
  actM1: numeric("act_m1").default("0"),
  actM2: numeric("act_m2").default("0"),
  actM3: numeric("act_m3").default("0"),
  actM4: numeric("act_m4").default("0"),
  actM5: numeric("act_m5").default("0"),
  actM6: numeric("act_m6").default("0"),
  actM7: numeric("act_m7").default("0"),
  actM8: numeric("act_m8").default("0"),
  actM9: numeric("act_m9").default("0"),
  actM10: numeric("act_m10").default("0"),
  actM11: numeric("act_m11").default("0"),
  actM12: numeric("act_m12").default("0"),
  sortOrder: integer("sort_order").default(0),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
  isDemo: boolean("is_demo").default(false),
});

// ---------------------------------------------------------------------------
// Cost Item Change Logs (audit trail / undo support)
// ---------------------------------------------------------------------------
export const costItemChangeLogs = pgTable("cost_item_change_logs", {
  id: serial("id").primaryKey(),
  costItemId: integer("cost_item_id"),
  projectId: integer("project_id").references(() => projects.id),
  changedBy: varchar("changed_by").references(() => users.id),
  changedByName: text("changed_by_name"),
  changedAt: timestamp("changed_at").defaultNow(),
  changeType: text("change_type").notNull(), // "created" | "updated" | "deleted"
  changeSummary: text("change_summary"),
  previousValues: text("previous_values"), // JSON string
  newValues: text("new_values"),           // JSON string
});

// ---------------------------------------------------------------------------
// Multi-Year WBS — fiscal year project rollup with SAP fields
// ---------------------------------------------------------------------------
export const multiYearWbs = pgTable("multi_year_wbs", {
  id: serial("id").primaryKey(),
  organizationId: integer("organization_id").references(() => organizations.id),
  projectId: integer("project_id").references(() => projects.id).notNull(),
  fiscalYear: text("fiscal_year").notNull(), // e.g. "FY24"
  sapProjectNumber: text("sap_project_number"),
  sapCapitalNumber: text("sap_capital_number"),
  sapExpenseNumber: text("sap_expense_number"),
  sapLaborNumber: text("sap_labor_number"),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at"),
  createdBy: varchar("created_by").references(() => users.id),
  isDemo: boolean("is_demo").default(false),
});

// ---------------------------------------------------------------------------
// Insert schemas + inferred types
// ---------------------------------------------------------------------------
export const insertCostItemSchema = createInsertSchema(costItems).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export const insertCostItemChangeLogSchema = createInsertSchema(costItemChangeLogs).omit({
  id: true,
  changedAt: true,
});
export const insertMultiYearWbsSchema = createInsertSchema(multiYearWbs).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type CostItem = typeof costItems.$inferSelect;
export type InsertCostItem = z.infer<typeof insertCostItemSchema>;

export type CostItemChangeLog = typeof costItemChangeLogs.$inferSelect;
export type InsertCostItemChangeLog = z.infer<typeof insertCostItemChangeLogSchema>;

export type MultiYearWbs = typeof multiYearWbs.$inferSelect;
export type InsertMultiYearWbs = z.infer<typeof insertMultiYearWbsSchema>;
