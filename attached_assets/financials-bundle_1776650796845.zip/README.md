# Single-Project Financials + Multi-Year WBS Bundle

Drop-in extraction of the **Financials tab** (cost-items grid) and
**Multi-Year WBS** feature for a React + Express + Drizzle + Postgres + shadcn
stack.

## What's inside

```
client/src/components/ProjectFinancialGrid.tsx   # The Financials tab UI
client/src/hooks/use-project-wbs.ts              # WBS list/create/update/delete hooks
server/financialsRoutes.ts                       # Express routes (cost-items + WBS)
shared/financialsSchema.ts                       # Drizzle tables, insert schemas, types
README.md                                        # This file
```

## Required dependencies (target project)

The bundle assumes these are already installed:

- `react`, `react-dom`
- `@tanstack/react-query` (v5)
- `wouter` (or any router — only needed if you wrap in routes)
- `drizzle-orm`, `drizzle-zod`, `zod`
- shadcn/ui components: `button`, `badge`, `input`, `select`, `dialog`,
  `label`, `textarea`, `scroll-area`
- `lucide-react` (icons)
- A `@/lib/queryClient` exporting `queryClient` and an `apiRequest(method, url, body?)` helper
- A `@/hooks/use-toast` exporting `useToast`
- Path aliases `@/` → `client/src` and `@shared/` → `shared/`

## Schema setup

Make sure `shared/schema.ts` already declares `users`, `projects`, and
`organizations` tables (the cost items reference `projects.id`, change logs
reference `users.id`, WBS references `organizations.id`).

Then pick **one** of these two integration paths. Do not do both — the
re-export pattern can create an import cycle since `financialsSchema.ts`
itself imports from `./schema`.

**Option A — separate file (recommended).** Copy
`shared/financialsSchema.ts` into your `shared/` folder as-is, then change
the bundled frontend imports to read from `@shared/financialsSchema`:

```ts
// client/src/components/ProjectFinancialGrid.tsx
import type { CostItem } from "@shared/financialsSchema";

// client/src/hooks/use-project-wbs.ts
import type { MultiYearWbs, InsertMultiYearWbs } from "@shared/financialsSchema";
```

**Option B — append to schema.ts.** Open `shared/financialsSchema.ts`,
delete its top `import ... from "./schema"` line (since `users` /
`projects` / `organizations` are already in scope), and paste the rest of
the file into your `shared/schema.ts`. The bundled frontend imports
(`@shared/schema`) will then resolve without changes.

After either path, apply the schema:

```bash
npm run db:push    # or: npx drizzle-kit push
```

## Storage layer

`server/financialsRoutes.ts` does all CRUD through a small `FinancialsStorage`
facade. Implement these methods against your data layer (drizzle queries,
Prisma, etc.). Reference implementation using drizzle:

```ts
import { eq, and, desc } from "drizzle-orm";
import { db } from "./db";
import { costItems, costItemChangeLogs } from "../shared/financialsSchema";
import { projects, users } from "../shared/schema";
import type { FinancialsStorage } from "./financialsRoutes";

export const financialsStorage: FinancialsStorage = {
  async getProject(id) {
    const [p] = await db.select().from(projects).where(eq(projects.id, id));
    return p ?? null;
  },
  async getUser(id) {
    const [u] = await db.select().from(users).where(eq(users.id, id));
    return u ?? null;
  },
  async getCostItems(projectId, fiscalYear) {
    const where = fiscalYear
      ? and(eq(costItems.projectId, projectId), eq(costItems.fiscalYear, fiscalYear))
      : eq(costItems.projectId, projectId);
    return db.select().from(costItems).where(where);
  },
  async getCostItem(id) {
    const [r] = await db.select().from(costItems).where(eq(costItems.id, id));
    return r ?? null;
  },
  async createCostItem(data) {
    const [r] = await db.insert(costItems).values(data).returning();
    return r;
  },
  async updateCostItem(id, patch) {
    const [r] = await db
      .update(costItems)
      .set({ ...patch, updatedAt: new Date() })
      .where(eq(costItems.id, id))
      .returning();
    return r;
  },
  async deleteCostItem(id) {
    await db.delete(costItems).where(eq(costItems.id, id));
  },
  async getCostItemChangeLogs(projectId) {
    return db
      .select()
      .from(costItemChangeLogs)
      .where(eq(costItemChangeLogs.projectId, projectId))
      .orderBy(desc(costItemChangeLogs.changedAt));
  },
  async createCostItemChangeLog(data) {
    await db.insert(costItemChangeLogs).values(data);
  },
};
```

## Route registration (auth contract)

> **Security MUST-READ.** Every endpoint registered by this module is mounted
> behind the `requireAuth` middleware you supply. There is **no built-in
> auth fallback** — if you omit `requireAuth` (or pass a no-op), the cost-item
> and WBS APIs will be open to the public internet. Provide a real
> session/passport guard. The optional `canAccessOrg` callback adds
> per-organization access control on top.

In your `server/routes.ts` (or wherever you `registerRoutes(app)`):

```ts
import type { RequestHandler } from "express";
import { registerFinancialsRoutes } from "./financialsRoutes";
import { db } from "./db";
import { financialsStorage } from "./financialsStorage";

const requireAuth: RequestHandler = (req, res, next) => {
  if (!req.isAuthenticated?.() || !(req.user as any)?.id) {
    return res.status(401).json({ message: "Authentication required" });
  }
  next();
};

registerFinancialsRoutes(app, {
  db,
  storage: financialsStorage,
  requireAuth,
  getUserId: (req) => (req.user as any)?.id ?? (req.session as any)?.userId ?? null,
  // Optional but strongly recommended: enforce org-level access
  canAccessOrg: async (userId, orgId) => {
    // your membership check here
    return true;
  },
});
```

## Frontend usage

Mount the component on your project detail page (Financials tab):

```tsx
import ProjectFinancialGrid from "@/components/ProjectFinancialGrid";

<ProjectFinancialGrid projectId={project.id} />
```

WBS hooks are imported per-need:

```tsx
import {
  useProjectWbs,
  useCreateProjectWbs,
  useUpdateProjectWbs,
  useDeleteProjectWbs,
} from "@/hooks/use-project-wbs";

const { data: wbs = [], isLoading } = useProjectWbs(projectId);
```

## API contract

### Cost items
| Method | Path                                            | Notes                              |
|--------|-------------------------------------------------|------------------------------------|
| GET    | `/api/projects/:projectId/cost-items`           | `?fiscalYear=2026` optional        |
| GET    | `/api/cost-items/:id`                           |                                    |
| POST   | `/api/projects/:projectId/cost-items`           | body: `InsertCostItem` (no projectId) |
| PUT    | `/api/cost-items/:id`                           | partial update                     |
| DELETE | `/api/cost-items/:id`                           |                                    |
| GET    | `/api/projects/:projectId/cost-items/history`   | audit log, newest first            |
| POST   | `/api/projects/:projectId/cost-items/undo`      | reverts the most recent change     |

### Multi-Year WBS
| Method | Path                                  | Notes                       |
|--------|---------------------------------------|-----------------------------|
| GET    | `/api/projects/:projectId/wbs`        | ordered by `fiscalYear`     |
| POST   | `/api/projects/:projectId/wbs`        | body: `InsertMultiYearWbs`  |
| PATCH  | `/api/wbs/:id`                        | partial update              |
| DELETE | `/api/wbs/:id`                        |                             |

## Data model recap

- **Cost items** are flat rows, but the UI builds a virtual 4-level hierarchy:
  `Financial View > Cost Category > Cost Specification > Cost Item`. There are
  no parent/child rows — the grouping comes from the three text fields on each
  row.
- Fiscal year months are **Oct–Sep**: `M1 = October`, ..., `M12 = September`.
- Each row carries three parallel monthly series: `aopM1..M12` (budget),
  `fcstM1..M12` (forecast), `actM1..M12` (actuals), plus `aopTotal/fcstTotal/actTotal`.
- **Change logs** capture every create/update/delete with JSON snapshots so the
  Undo endpoint can revert the most recent action.

## Not included (intentionally)

- DVS multi-project rollup and project-level grouping.
- DvsFinancialReport charts/analytics.
- Authentication / session middleware (provide your own via `getUserId`).
- Database migrations — run `drizzle-kit push` after merging schema.
